#Sawadogo Marie Fabienne
# 300101795
#Devoir 1 question 1


print("bonjour")

#Entrez des valeurs dans les variables
ValeurLivre = float(input("Entrez le Nombre de Livre : "))

ValeurOnce = float(input("Entrez le Nombre de Once : "))

#nombre de killogramme
ValeurKillo = float((ValeurLivre * 0.4536) + (ValeurOnce / 35.274 ))

print(ValeurLivre, "livres et", ValeurOnce, "onces  équivalent à : ", ValeurKillo, "killogrammes")

